
function openModal(id) {
  document.getElementById(id).style.display = "flex";
}
function closeModal(id) {
  document.getElementById(id).style.display = "none";
}
window.onclick = function(e) {
  document.querySelectorAll('.modal').forEach(m => {
    if (e.target == m) m.style.display = "none";
  });
};

function demoLogin(){
  const user = document.getElementById('loginUser').value || 'guest';
  alert('Demo login successful — welcome ' + user + ' (frontend only)');
  closeModal('loginModal');
}
function demoRegister(){
  const user = document.getElementById('regUser').value || 'newuser';
  alert('Demo register complete — ' + user + ' (no backend)');
  closeModal('registerModal');
}
